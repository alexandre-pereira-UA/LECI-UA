
def common_interests(lst):
    dic={}
    for i in lst:
        for j in lst:
            if i!=j and (j,i) not in dic:
                inter=[lst[i].intersection(lst[j])]
                dic[(i,j)]=inter


    return dic




def main():
    A = "reading"
    B = "eating"
    C = "traveling"
    D = "writing"
    E = "running"
    F = "music"
    G = "movies"
    H = "programming"

    interests = {
        "Marco": {A, D, E, F},
        "Anna": {E, A, G},
        "Maria": {G, D, E},
        "Paolo": {B, D, F},
        "Frank": {D, B, E, F, A},
        "Teresa": {F, H, C, D}
        }





    print("a) Table of common interests:")
    commoninterests = common_interests(interests)
    print(commoninterests)

    print("b) Maximum number of common interests:")
    maxCI = max([len(commoninterests[s][0]) for s in commoninterests])
    print(maxCI)

    print("c) Pairs with maximum number of matching interests:")
    maxmatches = max([(len(commoninterests[s][0]),s) for s in commoninterests])[1]
    print(maxmatches)

    print("d) Pairs with low similarity:")
    lowJaccard = [i for i in commoninterests if len(commoninterests[i][0])<=1]
    print(lowJaccard)


# Start program:
main()

