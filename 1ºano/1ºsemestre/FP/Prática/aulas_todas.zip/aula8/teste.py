'''
def oi(k):
    print(k)

a = {"c":lambda k:oi(k)}

a["c"]("hello")
'''
#getattr(self,"oi")
#globals()["oi"]()
#name,peso,altura



people=[("John",60,1.6),("Sabia",64.5,1.757),("Vitinho",45,1.5),("Mary",80,18)]
#quem tem acima de 70kg?
for i in people:
    if i[1]>70:
        print(i)
#or 
lst=[i for i in people if i[1]>70]

lst2=[i[0] for i in people if i[2]<1.7]
print(lst2)


l = ["A","B","C","D"]
newl=[(a,b) for a in l for b in l if a!=b]
print(newl)

