file = open("names.txt","r")
#dic = {i.split()[len(i.split())-1]:[] for i in file}

for i in file:
	i=i.strip()
	i=i.split()
	k=i[len(i)-1]
	v=i[0]
	if k in dic:
		dic[k].append(v)
	else:
		dic[k]=[v]

file.close()
print(dic)