import random

#Preços
#idade = 6 == 0
#  6<=idade<=12 = 2.5
# 13<=idade<=65 = 5
# idade>65 = 2.5







def calc_people(id):
    
    if id<6:
        return 0
    elif 13<=id<=65:
        return 5
    else:
        return 2.5

    




def calc_family():
    a=0
    b=100
    soma=0
    id1=random.randint(a, b)
    soma+=calc_people(id1)
    id2=random.randint(a, b)
    soma+=calc_people(id2)
    id3=random.randint(a, b)
    soma+=calc_people(id3)
    id4=random.randint(a, b)
    soma+=calc_people(id4)
    print("people1",id1)
    print("people2",id2)
    print("people3",id3)
    print("people4",id4)
    return soma
    


print("O preço dos bilhetes foi",calc_family()," euros")
