# You throw a dart that hits coordinates (x, y) on a dartboard.
# Create a program that gives you the score.
# See:
#   https://en.wikipedia.org/wiki/Darts#Dartboard
#   https://www.dimensions.com/element/dartboard

import math

print("Enter the coordinates in mm from the center of the board.")
x = float(input("x? "))
y = float(input("y? "))

# Points of the sectors, clockwise from the top
# Example: the sector right from the center is POINTS[5] == 6.
POINTS = (20, 1, 18, 4, 13, 6, 10, 15, 2, 17, 3, 19, 7, 16, 8, 11, 14, 9, 12, 5)

# COMPLETE...
r = 170
score=0
distance = math.sqrt(x**2+y**2)

if distance > r**2:
	print(falhou)

r_center = 6.35:
if (distance <= (r_center**2)):
	score+=50
	print(score)

r_w_center = 16:
if (distance <= (r_w_center**2 - r_center**2)):
	print(score)

print(distance)



if distance >17 and distance<22.55:
	print("ooo")

elif distance >10 and distance <=17:
	print("ignoraralgori")

elif distance>0.6 and distance<=10:
	print("ignorar0.6")
	angulo = math.degrees(math.atan2(y,x))
	print(angulo)
	if angulo<0:
		angulo+=365
	seg = math.floor((angulo/18)+1)
	print("seg",seg)


elif distance <=0.6:
	print("50 POINTS")


