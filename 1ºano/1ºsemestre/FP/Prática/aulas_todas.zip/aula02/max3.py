x1 = float(input("number1? "))
x2 = float(input("number2? "))
x3 = float(input("number3? "))



# x1 x2
# x1 x3
# x2 x3
maior = x1
if x2 > maior:
    maior = x2

if x3 > x1:
    maior = x3

print(maior)