num = float(input("numero:"))

if num%2 != 0:
	print("numero impar")
else:
	print("numero par")