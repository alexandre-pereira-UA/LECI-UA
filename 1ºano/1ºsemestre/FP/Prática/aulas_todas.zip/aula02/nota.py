
ctp = float(input("CTP?"))
cp = float(input("CP?"))

nf = 0.3*ctp + 0.7 *cp
print(nf)

if (ctp <6.5 or cp <6.5) or nf <10:
	print("REPROVADO")
	atpr= float(input("ATPR?"))
	apr = float(input("APR"))

	nr = 0.3 * max(ctp,atpr) + 0.7*max(cp,apr)
	print(nr)