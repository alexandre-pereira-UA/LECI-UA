segundos = int(input("seg:"))


p_base1 = 0.12  # 0 < x < 60
p_base2 = 0.18  #

if segundos == 90:
	print("preço:",p_base2)
else:
	preco = segundos//60
	if segundos%60 >0:
		preco+=1



	print("preço:", preco*p_base1)
