def iterative(n):
    fat=1
    for i in range(1,n+1):
        fat*=i
    return fat


def recursive(n):
    if n>=1:
        return(n*recursive(n-1))
    return 1
    



def countdown(n):
    for i in range(n,0,-1):
        print(i)

def Rcountdown(n):
    print(n)
    if n>0:
       
        return(Rcountdown(n-1))
        

print(Rcountdown(10))

print("iterative:",iterative(4))
print("recursive",recursive(4))

