num = int(input("N?"))


if (num%2==0 or num%3==0 or num%5==0 or num%7==0) and not(num in [1,3,5,7]):
    print("Num normal")
else:
    print("Num Primo")
