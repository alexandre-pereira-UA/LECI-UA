def hms2sec(h,m,s):
    sec = h*3600 + m*60 +s
    return sec


def sec2hms(time):
    h = time // 3600
    m = (time % 3600) // 60
    s = (time % 3600) % 60
    return h,m,s

