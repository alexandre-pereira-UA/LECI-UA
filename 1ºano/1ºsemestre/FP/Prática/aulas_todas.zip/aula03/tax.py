

def tax(r):
    print("r:",r)
    if r<=1000:
        print("r*0.1:")
        return r*0.1
    elif  1000<r<=2000:
        print("0.2*r -100")
        return 0.2*r -100
    else:
        print("0.3*r -300")
        return 0.3*r -300

print(tax(3000))
