
def Fibonacci(n):
    F0=0
    F1=1
    lst = [0]
    for i in range(n-1):
        F1=F0+F1
        F0=F1-F0
        lst.append(F0)        
    return lst

print(Fibonacci(6))
