


def media():
    soma=0
    n=0
    while True:
        s=input(">:")
        if s=="":
            break
        if not(s.isalpha()):
            s=float(s)
            soma+=s
            n+=1
        else:
            print("Not Number")
    return soma/n

print(media())
        
       
