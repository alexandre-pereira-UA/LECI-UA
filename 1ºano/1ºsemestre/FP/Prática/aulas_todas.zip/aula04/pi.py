



def leibnizPi4(n):
    pi=1
    a=3

    for i in range(1,n):
        if i%2 == 0:
            pi+=1/a
        else:
            pi-=1/a
        a+=2

    return pi

pi = leibnizPi4(1000)
print(pi*4)
