import random as r
import pandas as pd


def allMatches(lst):
    return [(a,b) for a in lst for b in lst if a!=b]


def getTeam():
    equipas=[]
    while True:
        a = input("Digite o nome dos equipas, não digite nada para acabar:")
        if a =="":
            break
        equipas.append(a)
    return equipas

def save(equipas):
    try:
        f = open("joga.txt","r")
        a= f.read()
        
        if a == "":
            equipas = getTeam()
            h=open("joga.txt","w")
            h.write(str(equipas))
            h.close()
        else:
            equipas=eval(a)
        f.close()
    except:
        h=open("joga.txt","w")
        equipas = getTeam()
        h.write(str(equipas))
        h.close()
    return equipas

def Partidas(equipas,ep):
    new={}
    for i in equipas:
        a=r.randint(0,5)#input(str(i[0])+"pontos?")
        b=r.randint(0,5)#input(str(i[1])+"pontos?")

        if a>b:
            #vitoria
            ep[i[0]][0]+=1
            #Pontos
            ep[i[0]][5]+=1
            #b ganha derrota
            ep[i[1]][2]+=1

        elif a==b:
            #Ganham empate os dois
            ep[i[0]][1]+=1
            ep[i[1]][1]+=1

        else:
            ep[i[1]][0]+=1
            ep[i[1]][5]+=1
            ep[i[0]][2]+=1

        ep[i[0]][3]+=a
        ep[i[1]][3]+=b

        ep[i[0]][4]+=b
        ep[i[1]][4]+=a



        new[i]=(a,b)
    return new

def createEquipaPontos(eP,equipas):
    #número de vitórias, de empates,de derrotas, o total de golos marcados e sofridos, e os pontos de cada equipa
    for i in equipas:
        eP[i]=[0,0,0,0,0,0]



def setWin(equipes):

    pontos = {}
    for equipe in equipes:
        pontos[equipe] = equipes[equipe][5]

    EqBestPoint = max(pontos, key=pontos.get)
    MaxPoint = pontos[EqBestPoint]

    HaveEmpate = [equipe for equipe, p in pontos.items() if p == MaxPoint]
    if len(HaveEmpate) == 1:
        print(f"A equipe vencedora é: {EqBestPoint} com {MaxPoint} pontos.")
    else:
        EqWin = None
        MaxG = 0
        MinG= float('inf')

        for equipe in HaveEmpate:
            gols_marcados=equipes[equipe][3]
            gols_sofridos=equipes[equipe][4]
            
            if gols_marcados > MaxG:
                EqWin = equipe
                MaxG = gols_marcados
                MinG = gols_sofridos
            elif gols_marcados == MaxG and gols_sofridos < MinG:
                EqWin = equipe
                MaxG = gols_marcados
                MinG = gols_sofridos


        print(f"A equipe vencedora é: {EqWin} com {MaxPoint} pontos, {MaxG} gols marcados e {MinG} gols sofridos.")



def printTable(dic):
    table=[(i,dic[i][0],dic[i][1],dic[i][2],dic[i][3],dic[i][4],dic[i][5]) for i in dic ]
    val=('Equipa','Vitórias', 'Empates', 'Derrotas', 'Golos marcados', 'Golos sofridos', 'Pontos')
    
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', 1000)
    df = pd.DataFrame(table,columns=val)
    df= df.sort_values(by='Pontos', ascending=False)
    print(df.to_string(index=False))



    

def main():
    equipas=[]
    equipasPontos={}
    equipas=save(equipas)
    createEquipaPontos(equipasPontos,equipas)
    equipas=allMatches(equipas)
    Partidas(equipas,equipasPontos)
    printTable(equipasPontos)
    setWin(equipasPontos)

    #print(equipas)
    #print(equipasPontos)

main()