# Complete este programa como pedido no guião da aula.
import pandas as pd

def listContacts(dic):
    """Print the contents of the dictionary as a table, one item per row."""
    table=[]
    for i in dic:
        linha=[]
        linha.append(i)
        for j in dic[i]:
            linha.append(j)
        table.append(tuple(linha))
    print(pd.DataFrame(table,columns=("Numero","Nome","Morada")))


def filterPartName(contacts, partName):
    tells={}
    partName=partName.lower()
    for k,v in contacts.items():

        if partName in v[0].lower():
            tells[k]=v
    return tells



'''
def nameToTels(partName, telList, nameList):
    tels=[]
    for i in range(len(nameList)):
        if partName in nameList[i]:
            tels.append(telList[i])
    return tels
'''

def getName(contacts):
    while True:
        numero =input("Numero:")
        if contacts.get(numero):
            print(contacts[numero][0],"é o dono desse numero", numero)
            break
        print("Numero errado")



def remContat(contacts):
    while True:
        numero =input("Numero:")
        if numero in contacts:
            del contacts[numero]
            break
        print("Numero errado")



def addContat(contactos):
    name = input("Nome:")
    numero =input("Numero:")
    morada  =input("Morada:")
    while len(numero)<9:
        print("Numero invalido")
        numero =input("Numero:")
    contactos[numero]=[name,morada]


def menu():
    """Shows the menu and gets user option."""
    print()
    print("(L)istar contactos")
    print("(A)dicionar contacto")
    print("(R)emover contacto")
    print("Procurar (N)úmero")
    print("Procurar (P)arte do nome")
    print("(T)erminar")
    op = input("opção? ").upper()   # converts to uppercase...
    return op


def main():
    """This is the main function containing the main loop."""

    # The list of contacts (it's actually a dictionary!):
    contactos = {"234370200": ["Universidade de Aveiro","Santiago, Aveiro"] ,
        "727392822": ["Cristiano Aveiro","Porto"],
        "887555987": ["Marta Maia","Coimbra"],

        }

    op = ""
    while op != "T":
        op = menu()
        if op == "T":
            print("Fim")
        elif op == "L":
            print("Contactos:")
            listContacts(contactos)
        elif op=="A":
            print("Fale o contato:")
            addContat(contactos)
        elif op=="R":
            listContacts(contactos)
            print("Fale o numero que deseja remover:")
            remContat(contactos)
        elif op=="N":
            print("Fale o numero")
            getName(contactos)
        elif op =="P":
            print("Digite parte do nome:")
            partName=input("Nome:")
            listContacts(filterPartName(contactos, partName))

        else:
            print("Não implementado!")
    

# O programa começa aqui
main()

