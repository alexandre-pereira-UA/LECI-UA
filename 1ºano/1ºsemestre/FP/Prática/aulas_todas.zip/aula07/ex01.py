pt2eng={"as":"the","os":"the","e":"and","praia":"beach","meninas":"girls"}

frase= "as meninas estão na praia"
print("Frase Original:",frase)
frase=frase.split()
newf=""
for i in frase:
    if i in pt2eng:
        newf+=pt2eng[i] +" "
    else:
        newf+=i+" "
print("ENG:",newf)


