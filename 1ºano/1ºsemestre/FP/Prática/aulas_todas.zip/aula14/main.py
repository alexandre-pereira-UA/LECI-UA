import pandas as pd
import os 


"""
Posição no Ranking
Nome do Clube
País do Clube
Score (pontos acumulados) atual
Subida ou descida no ranking (número de posições)
Score (pontos acumulados) do ano anterior
Indicação se subiu ou desceu no ranking (+ ou -)
"""
PR,NC,PC,SAT,SD,SAN,IND = 0,1,2,3,4,5,6
def readFile(name):
	f = open(name,"r")
	lst=[]
	for i in f:
		i = i.split(",")
		i[IND]=i[IND].strip()
		lst.append(tuple(i))
	f.close()
	return lst


"""
2 - Uma função que receba como argumento o nome de um país e que imprima no ecrã os
clubes desse país, o número respetivo no ranking e o score atual.
"""
def nameTeamForCountry(name,tp):
	lst=[]
	for i in tp:
		if i[PC] == name:
			print("-------")
			lst.append([i[NC],i[PR],i[SAT]])
			print(i[NC],",",i[PR],",",i[SAT])

			print("-------")
			print()
	return lst
"""
3 – Uma função com base na anterior que receba também o nome de um ficheiro de output e
que escreva nesse ficheiro a informação impressa no ecrã da alínea anterior
"""
def writeTeam(name,ntc):
	f = open(name+".txt","w")
	for i in ntc:
		f.write(",".join(i)+"\n")
	f.close()

"""
4 – Uma função que receba a lista de túpulos e que devolva um dicionário em que a chave é o
país sede dos clubes e o valor correspondente deverá ser uma lista com o nome de todos os
clubes desse país. 
"""
def lstToDic(tp):
	dic={}
	for i in tp:
		a=i[PC]
		if a in dic:
			dic[a].append(i[NC])
		else:
			dic[a]=[i[NC]]
	return dic

def DICNCRC(tp):
	dic={}
	for i in tp:
		a=i[PC]
		if a in dic:
			dic[a].append( (i[NC],int(i[PR]) ))
		else:
			dic[a]=[ (i[NC],int(i[PR])) ]
	return dic


"""
5 – Uma função que receba a lista de túpulos e devolva o túpulo correspondente ao clube que
mais subiu no ranking. 
"""
def verifyRank(tp):
	k=""
	a=0
	for i in tp:
		if i[IND]=="+":
			b=int(i[SAT])-int(i[SAN])
			if b>a:
				a=b
				k=i[NC]
	return k



"""
6 - Uma função que receba o nome de um clube e que imprima no ecrã os dados desse clube se
este existir e uma mensagem de erro nos restantes casos. 
"""
def infoClube(name,tp):
	clubes = [i[NC] for i in tp]

	if name in clubes:
		lst = tp[clubes.index(name)]
		return ", ".join(lst)
	else:
		return "Esse Clube não exite"

"""

– Uma função que determine o ranking médio de cada um dos países e o apresente no ecrã (o
ranking médio determina-se somando o ranking de todos os clubes de um dado país e dividindo
pelo número de clubes desse país. 
"""
def rankCountry(dic):
	print()
	nDic=[]
	for i in dic:
		lst = [int(i[1]) for i in dic[i]]
		nDic.append((i,round(sum(lst)/len(lst))))
	sorted(nDic)
	print(nDic)
	return nDic


def teste(tp):
	lst = [PR,NC,PC,SAT,SD,SAN,IND]

	dic={}
	for i in lst:
		dic[i]=[k[i] for k in tp]
	return dic



"""
– Desenvolva ainda uma função que apresente um menu com as diferentes opções
desenvolvidas nas alíneas anteriores e que as permita testar. A opção 0 permitirá abandonar o
programa, em todas as restantes opções após a chamada da função respetiva deverá ser
apresentado de novo o menu e deverá ser possível escolher outra opção. 
"""

def main():
	
	tp=[]
	NTC=[]
	dic={}
	
	RCDic =[]

	while True:
		inp = input(">:")
		if tp==[] and inp!="1":
			print("PRIMA 1 PRIMEIRO")
			continue
		os.system('cls' if os.name == 'nt' else 'clear')
		match(inp):
			case "1":
				tp = readFile("Soccer_Football Clubs Ranking.csv")[1:]
				df = pd.DataFrame(teste(tp))

				print(df.to_string(index=False))
			case "2":
				NTC = nameTeamForCountry("Portugal",tp)
				d={
					"clubes":[i[0] for i in NTC],
					"ranking":[i[1] for i in NTC],
					"score atual":[i[1] for i in NTC]
					}
				df = pd.DataFrame(d)

				print(df.to_string(index=False))
				#print(NTC)
			case "3":
				writeTeam("teste",NTC)

			case "4":
				dic = lstToDic(tp)
				c = {
					"Pais":[i[1] for i in tp],
					"Rank":[i[0] for i in tp]
					}
				df = pd.DataFrame(c)

				print(df.to_string(index=False))
				#print(dic)

			case "5":
				k = verifyRank(tp)
				print(k)

			case "5":
				IC = infoClube("Saint George",tp)
				print(IC)

			case "6":
				RCDic =rankCountry(DICNCRC(tp))

			case "0":
				break
			case _:
				print("NÃO VALIDO")



main()




