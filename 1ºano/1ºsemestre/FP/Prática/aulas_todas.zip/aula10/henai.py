N_D=3
mapa = {
"A":[i+1 for i in range(N_D)],
"B":[0 for i in range(N_D)],
"C":[0 for i in range(N_D)]
}
print('A-Origem    B-Temporario   C-Destino')

for i in range(N_D):
	print(mapa["A"][i],"              ",mapa["B"][i],"            ",mapa["C"][i])
print()
def verify(lst):
	for i in range(len(lst)-1,0,-1):
		if lst[i]==0:
			return i
	return 0

def verify2(lst):
	for i in range(len(lst)):
		if lst[i]!=0:
			return i
	return 0


def move_disc(disco,de, para):
	print("Move disco de {} para {}".format(de,para))
	print()
	mapa[de][verify2(mapa[de])]=0
	mapa[para][verify(mapa[para])]=disco

	print('A-Origem    B-Temporario   C-Destino')

	for i in range(N_D):
		print(mapa["A"][i],"              ",mapa["B"][i],"            ",mapa["C"][i])
	print()




def henoi(discos, origem, temporario, destino):
	if discos==0:
		return
	#1º fase mover d-1 discos de A para B
	henoi(discos-1,origem,destino,temporario)

	#2º fase mover disco maior de A para C
	move_disc(discos,origem,destino)

	#3 fase: mover d-1 discos de B para C
	henoi(discos-1,temporario,origem,destino)


henoi(N_D,"A","B","C")