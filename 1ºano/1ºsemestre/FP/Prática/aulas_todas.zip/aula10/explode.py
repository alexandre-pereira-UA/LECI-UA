def explode(nome,obj):



	if not(isinstance(obj,dict)):
		for k,i in enumerate(obj):
			print(f"{nome}[{k}] = {i!r}")
			if not(isinstance(i,(float,int,str))):
				explode(nome+f"[{k}]",i)
	else:
		for k,i in obj.items():
			print(f"{nome}[{k}] = {i!r}")
			if not(isinstance(i,(float,int,str))):
				explode(nome+f"[{k}]",i)
				






a = [1,["a",["b",2],3,4,{"oi":"ab","i":[1,2]}]]
explode("a",a)