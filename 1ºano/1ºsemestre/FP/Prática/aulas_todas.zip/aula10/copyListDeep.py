#copyListDeep.py
import copy

def deepCopy(lst):

	return_list = []

	for value in lst:
		if isinstance(value,list):
			return_list.append(deepCopy(value))
		else:
			return_list.append(value)
	return return_list



h = [1,2,["a","b"],4]
f = deepCopy(h)
print(h)
t= h[::]
print(f)
k=(copy.deepcopy(h))



print(h[2] is t[2])
print(h[2] is f[2])
print(h is k)

