#sortedRecursion.py
#QuickSort
import random
import time

def sortedRecursion(lst):
	if len(lst)<=1:
		return lst[:]
	chose=lst[0]
	left=[i for i in lst[1:] if i<chose]
	right = [i for i in lst[1:] if i>=chose]
	return sortedRecursion(left)+[chose]+sortedRecursion(right)



l= [i for i in range(100)]

#print(l)

n=time.time()
print(sorted(l))
print("Iteração:",time.time()-n)

#shellsort    teamSorte


n=time.time()
print(sortedRecursion(l))
print("Recur:",time.time()-n)

