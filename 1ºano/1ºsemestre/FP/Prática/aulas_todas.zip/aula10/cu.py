"""
endX("xxre") → "rexx"
endX("xxhixx") → "hixxxx"
endX("hixhix") → "hihixx"
"""

def endX(i):
   if len(i)<2:
         return i
   if i[0]=="x":
      return endX(i[1:])+"x"
   return i[0]+endX(i[1:])
print(endX("xxhixx"))