def reverseDigits(value):
   return reverseAux(value, 0)

def reverseAux(partValue, partReversed):
	if partValue//10<=0:
		return partReversed*10 + partValue
	if partReversed==0:
		return reverseAux(partValue//10,partValue%10)
	return reverseAux(partValue//10,10*partReversed + partValue%10)	


print(reverseDigits(1234))