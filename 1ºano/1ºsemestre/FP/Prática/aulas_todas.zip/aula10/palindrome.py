#Palindromo
import time

def is_Palinm(string):
	string = "".join(i.casefold() for i in string if i!=" " and i.isalpha())
	#newS = "".join(string[i] for i in range(len(string)-1,-1,-1))
	#print(newS)
	if len(string)<1:
		return True
	else:
		return is_Palinm(string[1:-1]) and string[0]==string[-1]



s="II II"
n=time.time()
print(is_Palinm(s))
print(time.time()-n)

n=time.time()
string = "".join(i.casefold() for i in s if i!=" " and i.isalpha())
newS = "".join(string[i] for i in range(len(string)-1,-1,-1))
print(string==newS)
print(time.time()-n)