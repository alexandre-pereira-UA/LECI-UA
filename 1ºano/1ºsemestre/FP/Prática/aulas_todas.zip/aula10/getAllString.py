def getAllStrings(obj):
	lst =[]
	for i in obj:
		if isinstance(i,str):
			lst.append(i)
		elif not(isinstance(i,(float,int))):
			lst+=(getAllStrings(i))
	return lst

a = ["none",2,["three",4,"y"]]
print(getAllStrings(a))