import sys
print("Number of args:", len(sys.argv))
print("Argument List:",sys.argv)
