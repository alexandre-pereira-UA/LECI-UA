fin = open("oi.txt","w")

print("X:",10,file=fin)

fin.close()



fin = open("nums.txt","r")
print(repr("Olhá"))
fin.seek(0)
print(fin.readline())
#for line in fin:
#    print(repr(line))
#    print(line)


fin.close()

