import os
for i in os.listdir():
    print(i,"                   size:",os.stat(i).st_size, " bytes")


