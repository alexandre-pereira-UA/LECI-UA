# Complete o programa!

# a)
def loadFile(fname, lst):

    file = open(fname,"r")
    #numero-0,nome-1,nota1-5,nota2-6,nota3-7
    for j,i in enumerate(file):
        
        if j>0:
            i=i.split('\t')
            lst.append((i[0],i[1],float(i[5]),float(i[6]),float(i[7].strip())))
    file.close()


def notafinal(lst):
    s=0
    for i in lst:
        s+=i
    s/=len(lst)
    return round(s,4)

def printPauta(lst):
    h=[]
    for i in lst:
        a=i[:2:]
        h.append((a[0], a[1], notafinal(i[2::])))
    h.append(("Numero","Nome","Nota"))
    h.sort()
    f = open("t.txt","w")
    f.write(str(h))
    f.close()
    for i in h:
        print("|{:} | {:} | {:^4} |".format(*i))



...

# d)
def main():
    lst = []
    # ler os ficheiros
    loadFile("school1.csv", lst)
    #loadFile("school2.csv", lst)
    #loadFile("school3.csv", lst)
    print(lst[0][:2:])
    print(lst[0][2::])
    print(notafinal(lst[0][2::]))
    printPauta(lst)
    # ordenar a lista
    ...
    
    # mostrar a pauta
    ...


# Call main function
if __name__ == "__main__":
    main()


