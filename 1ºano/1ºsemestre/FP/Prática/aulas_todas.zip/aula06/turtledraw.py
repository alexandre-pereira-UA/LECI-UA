# Exercise 5 on "How to think like a computer scientist", ch. 11.

import turtle

drawPos=open("drawing.txt","r")
t = turtle.Turtle()


state=""
for i in drawPos:
     
    if "UP" in i or "DOWN" in i:
        state=i[:-1]
        
        

    else:
        i=i.split()
        i[0]=int(i[0])
        i[1]=int(i[1])
        match(state):
            case "UP":

                t.up()
                t.goto(*i)
            case "DOWN":
                t.down()
                t.goto(i[0],i[1])


# Use t.up(), t.down() and t.goto(x, y)

# Put your code here
...

# wait
turtle.Screen().exitonclick()
drawPos.close()
