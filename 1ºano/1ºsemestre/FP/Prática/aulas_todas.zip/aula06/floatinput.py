import math

def floatInput(prompt):
    res = (input(prompt))
    try:
        res=float(res)
        return res
    except:
        return "ERROR NOT A FLOAT"


def floatInput2(prompt,m="-inf",ma="inf"):
    res = (input(prompt))


    try:
        res=float(res)

        if m!="-inf" and ma!="inf":
            if res>ma or res<m:
                return "ERROR! Valor não está no intervalo [{},{}]".format(m,ma)
        elif m=="-inf" and m!="inf":
            if res>ma:
                return "ERROR! Valor não está no intervalo [{},{}]".format(m,ma)
        else:
            if res<m:
                return "ERROR! Valor não está no intervalo [{},{}]".format(m,ma)



        return res
    except:
        return "ERROR NOT A FLOAT"    


def main():
    '''    
    print("a) Try entering invalid values such as 1/2 or 3,1416.")
    v = floatInput("Value? ")
    print("v:", v)

    print("b) Try entering invalid values such as 15%, 110 or -1.")
    h = floatInput2("Humidity (%)? ", 0, 100)
    print("h:", h)
    '''
    print("c) Try entering invalid values such as 23C or -274.")
    t = floatInput2("Temperature (Celsius)? ", m=-273.15)
    print("t:", t)

    # d) What happens if you uncomment this?
    # impossible = floatInput("Value in [3, 0]? ", min=3, max=0)

    return

if __name__ == "__main__":
    main()
