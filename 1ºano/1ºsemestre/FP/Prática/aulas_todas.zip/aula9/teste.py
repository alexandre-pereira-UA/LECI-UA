import bisect




lst =[4,5,7,2,1]
lst2=["maria","josé","joão"]
lst.sort()
lst2.sort()

x=1
a = bisect.bisect_left(lst,x)
print(a,lst[a])


x="maria"
a = bisect.bisect_left(lst2,x)
print(a,lst2[a])



dates = [
            (1910,10,5,"Republic"),
            (1974,4,25,"Liberty"),
            (1640,12,1,"Independence")
        ]

print(sorted(dates))

print(sorted(dates,key=lambda t:t[3]))

print(sorted(dates,key=lambda t:(t[1],t[2] ) ) )

import time
class teste:
    def __init__(self,i):
        self.value=i
    def u(self):
        self.value+=1
        #print(self.value)


h = [teste(i) for i in range(1000000)]
a=(time.time())
r=list(map(lambda teste:teste.u(),h))
m=(time.time()-a)

a=(time.time())
[i.u() for i in h]
c=(time.time()-a)

a=(time.time())
for i in h:
    i.u()
f=(time.time()-a)


l={"map":m,"comp":c,"for":f}
for i in sorted(l, key = l.get):
    print(i, l[i])

print(l["for"]-l["comp"])
print(l["comp"]-l["for"])