a=6
lst1 = [i for i in range(a)]





print(lst1,len(lst1))
med = len(lst1)//2
lst1=sorted(lst1)
if len(lst1)%2!=0:
	print(lst1[med])
else:
	print( (lst1[med] +lst1[med-1])/2 )