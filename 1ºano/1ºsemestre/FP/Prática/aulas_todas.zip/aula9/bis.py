import bisect as b
f=open("wordlist.txt","r")
lst=[i.strip() for i in f]
f.close()
'''
4)

num=b.bisect_left(lst,"ea")
print(num)
print(lst[num])
print(b.bisect_left(lst,"eb")-num-1)
num=b.bisect_left(lst,"eb")
print(num)
print(lst[num])


num=b.bisect_left(lst,"truo")
print(lst[num].replace("tru","")[0])
'''


def repl(s):
	abc="abcdefghijklmnopqrstuvxwyz"
	return s.replace(s[len(s)-1],abc[abc.find(s[len(s)-1])+1])


#5)
s = "hu"#input(">:")
n1=b.bisect_left(lst,s)
n2=b.bisect_left(lst,repl(s))
k=0
for i in range(n1,n2):
	print(lst[i].replace(s,""),end=", ")
	if k>5:
		print()
		k=0
	k+=1

