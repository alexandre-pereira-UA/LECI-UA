l = open("wordlist.txt","r")
dic ={}
for j in l:
	j=j.strip()
	for i in j: 
		if i in dic:
			dic[i]+=1
		else:
			dic[i]=1

print([(i,dic[i]) for i in sorted(dic,reverse=True)])
l.close()