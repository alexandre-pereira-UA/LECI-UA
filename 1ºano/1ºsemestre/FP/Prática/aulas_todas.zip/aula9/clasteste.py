import math as m
import bisect as bi


func = lambda x:x+m.sin(10*x)
x_min=0.2
x_max=0.4

div = 100
tol=1/div
lst=[func(i/div) for i in range( int(x_min*div), int(x_max*div),  int(tol*div) )]
print(lst)

neg=0
pos=0
for i in range(1):
	s=bi.bisect_left(lst,0.3)
	print("f1",s)
	print("lst f1", lst[s])
