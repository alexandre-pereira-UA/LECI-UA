hora = int(input("hora:"))
minuto = int(input("minuto:"))
andar = 10
correr = 6


S = (1*andar) + (3*correr) + (4*andar)
minuto+=S
hora+= minuto//60
minuto = minuto%60


print("{:02d}:{:02d}:{:02d}".format(hora, minuto, 00))

#res = 8