
time = int(input("s: "))
h = time // 3600
m = (time % 3600) // 60
s = (time % 3600) % 60

print("{:02d}:{:02d}:{:02d}".format(h, m, s))
