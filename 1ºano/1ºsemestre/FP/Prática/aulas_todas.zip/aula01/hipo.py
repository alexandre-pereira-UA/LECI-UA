import math

catA = input("Cat_A:")
catB = input("Cat_B:")


catA=float(catA)
catB=float(catB)

C=math.sqrt(catA**2 + catB**2)

print("Hipotenusa:",C)

angle = math.asin(catA/C)
angle = math.degrees(angle)


print("Angle -> CatA to Hip:",angle)

