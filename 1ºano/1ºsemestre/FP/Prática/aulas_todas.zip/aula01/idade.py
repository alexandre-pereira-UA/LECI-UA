# Complete o programa.
nome = input("Como te chamas?")
nascimento = int(input("Em que ano nasceste?"))
ano_tera = 2030 - nascimento
print("{} fará {} em 2030".format(nome,ano_tera))