andares = int(input("Andares:"))
casa_p = int(input("casa_por_andar:"))
h_andar = 3 #m

metros=0



u1 = casa_p * 4 * h_andar

un = u1 + u1*(andares-1)
S = ((u1 + un) * andares)/2

ano = S * 365
print(u1,un,S,ano)
# 1 - 12, 2 - 24 - 36
#elevador 72*365 = 26280 - 26.2km
'''
for i in range(1+andares):
    metros+=casa_p*2*i*h_andar
    print(casa_p*2*i*h_andar)
metros*=365'''



print("km:",int(ano/1000)," horas:",int(ano/3600))

