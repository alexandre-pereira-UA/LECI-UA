import math as m
# This program reads the coordinates of two points (x1,y1) and (x2,y2).

x1 = float(input("x1? "))
y1 = float(input("y1? "))
x2 = float(input("x2? "))
y2 = float(input("y2? "))

# create tuples from coordinates
p1 = (x1, y1)
p2 = (x2, y2)

print("Point1:", p1)
print("Point2:", p2)

# Compute and print the distance between the points!
# ...
distance = m.sqrt((p2[0]-p1[0])**2 + (p2[1]-p1[1])**2)
print("A distancia do ponto 1 para o 2 é ",distance)
