PF = 20
PC = 24.95 # 
IMP = 0.23 # %
SPA = 0.20

#(PF + lucro) * (1 + IMP) = SPA - PC
Lucro = -((SPA - PC)/(1 + IMP)) - PF
print("Lucro:",round(Lucro,4)," euros, "," 500 exemplares:",round(500*Lucro,4)," euros")

imposto = PC - ((PF + Lucro)  + SPA * IMP)  
print("imposto por livro: ",round(imposto,4)," euros, imposto em 500 livros: ",round(imposto*500,4)," euros")
