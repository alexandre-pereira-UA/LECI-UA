largura = 21.0
altura = 29.2

area = largura * altura
print("Area:",area)
perimetro = 2*(altura + largura)
print("Perimetro:",perimetro)


