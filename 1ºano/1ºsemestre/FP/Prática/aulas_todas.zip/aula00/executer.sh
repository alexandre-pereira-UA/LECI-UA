#!/bin/bash

# Diretório onde o script está localizado
diretorio_atual="$(dirname "$0")"

# Lista de arquivos .py no mesmo diretório do script
programas_python=($(find "$diretorio_atual" -maxdepth 1 -type f -name "*.py"))

# Exibe a lista de programas Python disponíveis
echo "Programas Python disponíveis para execução:"
for ((i=0; i<${#programas_python[@]}; i++)); do
  echo "[$i] ${programas_python[$i]}"
done

# Solicita a escolha do usuário
read -p "Digite o número do programa Python que deseja executar: " escolha

# Verifica se a escolha é válida
if [[ $escolha =~ ^[0-9]+$ && $escolha -ge 0 && $escolha -lt ${#programas_python[@]} ]]; then
  programa_escolhido="${programas_python[$escolha]}"
  chmod +x "$programa_escolhido"
  python3 "$programa_escolhido"
else
  echo "Escolha inválida."
fi

