

def shorten(st):
    newstr=""
    for i in st:
        if i.isupper():
            newstr+=i
    return newstr

print(shorten("Universidade de Aveiro"))
print(shorten("United Nations Organization"))
