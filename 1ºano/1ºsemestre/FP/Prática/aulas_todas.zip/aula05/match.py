def allMatches(lst):
    assert len(lst) >=2 "requeres two or more teamns"
    newlst=[]
    for i in lst:
        for j in lst:
            if i!=j:
                newlst.append(i,j)
    return newlst
