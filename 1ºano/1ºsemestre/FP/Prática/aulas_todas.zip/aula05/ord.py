

def enigma(word:str):
    new=""
    for i,j in enumerate(word):
        a = ord(j)
        if a == 32:
            new+=" "
            continue
        print(a,( chr( a + i + 1 ) ))
        new+=( chr( a + i + 1 ) )
    return new


def enigma2(word:str):
    return "".join([chr( ord( j ) + i +1 ) for i,j in enumerate(word)])


word = input(">=")
print(enigma2(word))
