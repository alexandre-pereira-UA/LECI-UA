


def Num():
    lst=[]
    while True:
        a = input("Não digite nada para desligar >:")
        
        if a.isdigit():lst.append(int(a))

        elif a=="": return lst

        else: print("Não é numero")



def up(l):
    for i in range(len(l)):
        l[i]+=1




def strLen(word:str):
    a=0
    for i in word:
        if i.isalpha():
            a+=1
    return a


def strLen2(word:str):
    return  len([ele for ele in word if ele.isalpha()])

l=([1,2,3])

word=input(">:")


#print([(i,j) for i in range(10) for j in range(10)])
