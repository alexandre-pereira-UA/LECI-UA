

def inputFloatList():
    lst=[]
    while True:
        i=input(">:")
        if i=="":
            return lst
        i=float(i)
        lst.append(i)

def countLower(lst, v):
    n=0
    for i in lst:
        if i<v:
            n+=1
    return n

def minmax(lst):
    mi=lst[0]
    ma=lst[0]
    for i in lst:
        if i<mi:
            mi=i
        if i>ma:
            ma=i
    return (mi,ma)



lst=inputFloatList()
print(lst)
print(countLower(lst,4.0))
print(minmax(lst))

        

