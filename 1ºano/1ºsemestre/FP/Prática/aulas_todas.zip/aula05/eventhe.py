def evenThenOdd(s):
    par=[]
    im=[]
    for i in range(len(s)):
        if i%2==0:
            par.append(s[i])
        else:
            im.append(s[i])
    return "".join(par)+"".join(im)
    

def rem_adj(s):
    ns=""
    ant=""
    for i in s:
        if i!=ant:
            ns+=i
        ant=i
    return ns



def repeatN(n):
    lst = []
    for i in range(1,n+1):
        for j in range(i):
            lst.append(i)
    return lst

print(repeatN(4))
        

print(evenThenOdd("abcd"))




