def ispalindrome(s):
    return s==s[::-1]

print(ispalindrome("tenet"))
print(ispalindrome("oi"))
